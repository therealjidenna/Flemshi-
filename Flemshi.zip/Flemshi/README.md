# Flemshi

A Jumia-style shopping app for Android, built with Kotlin and Jetpack Compose.

## Open and run
1. Open this folder in Android Studio (Koala or newer).
2. Let Gradle sync (it downloads Gradle 8.7 and dependencies, so you need internet once).
3. Press Run on an emulator or a phone.

## What's included
- Home: search, category chips, product grid with discounts
- Product details with "Add to cart"
- Cart: change quantity, remove items, subtotal in Naira
- Sample products stored locally in `data/SampleData.kt`

## Next steps
1. Firebase: create a project, add `google-services.json` to `app/`, then uncomment the Firebase lines in both `build.gradle.kts` files. Replace `SampleData` with Firestore.
2. Login and signup (Firebase Auth)
3. Checkout and orders
4. Paystack payments
5. Seller side (vendors listing products)
6. Real product images (Coil + Firebase Storage)
