package com.flemshi.app.ui

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.flemshi.app.ui.screens.CartScreen
import com.flemshi.app.ui.screens.HomeScreen
import com.flemshi.app.ui.screens.ProductScreen

@Composable
fun FlemshiApp() {
    val navController = rememberNavController()
    val shopViewModel: ShopViewModel = viewModel()

    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(
                viewModel = shopViewModel,
                onProductClick = { id -> navController.navigate("product/$id") },
                onCartClick = { navController.navigate("cart") }
            )
        }
        composable(
            route = "product/{id}",
            arguments = listOf(navArgument("id") { type = NavType.IntType })
        ) { entry ->
            ProductScreen(
                productId = entry.arguments?.getInt("id") ?: -1,
                viewModel = shopViewModel,
                onBack = { navController.popBackStack() },
                onCartClick = { navController.navigate("cart") }
            )
        }
        composable("cart") {
            CartScreen(
                viewModel = shopViewModel,
                onBack = { navController.popBackStack() },
                onCheckout = {
                    // TODO: Paystack checkout goes here
                }
            )
        }
    }
}
