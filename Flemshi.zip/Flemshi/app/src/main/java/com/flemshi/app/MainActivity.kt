package com.flemshi.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.flemshi.app.ui.FlemshiApp
import com.flemshi.app.ui.theme.FlemshiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FlemshiTheme {
                FlemshiApp()
            }
        }
    }
}
