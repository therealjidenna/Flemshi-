package com.flemshi.app.data

// Temporary local data. Replace with Firestore later.
object SampleData {

    val categories = listOf(
        "All", "Phones", "Fashion", "Electronics", "Home", "Beauty", "Groceries"
    )

    val products = listOf(
        Product(1, "Smartphone X12 128GB", "6.5\" display, 128GB storage, 4GB RAM, dual SIM and a 5000mAh battery.", 145_000, 175_000, "Phones", "📱", 4.5f, "TechHub NG"),
        Product(2, "Wireless Earbuds Pro", "Bluetooth 5.3, noise reduction, up to 24 hours of battery with the case.", 18_500, 25_000, "Electronics", "🎧", 4.2f, "SoundCity"),
        Product(3, "Men's Ankara Shirt", "Hand-finished Ankara print shirt, available in sizes S to XXL.", 12_000, null, "Fashion", "👕", 4.7f, "Lagos Threads"),
        Product(4, "Women's Leather Handbag", "Durable faux leather handbag with two compartments and a zip pocket.", 22_000, 30_000, "Fashion", "👜", 4.4f, "Bella Styles"),
        Product(5, "Smart LED TV 43\"", "Full HD smart TV with built-in apps, 3 HDMI ports and 2 USB ports.", 215_000, 250_000, "Electronics", "📺", 4.6f, "HomeVision"),
        Product(6, "Non-stick Cookware Set", "7-piece non-stick pot and pan set, suitable for gas and electric cookers.", 38_000, 45_000, "Home", "🍳", 4.3f, "KitchenPlus"),
        Product(7, "Shea Butter Body Cream", "100% natural shea butter body cream, 500ml, for dry skin.", 4_500, null, "Beauty", "🧴", 4.8f, "Pure Glow"),
        Product(8, "Premium Rice 50kg", "Clean, stone-free long grain parboiled rice, 50kg bag.", 78_000, 85_000, "Groceries", "🍚", 4.5f, "FreshMart"),
        Product(9, "Power Bank 20,000mAh", "Fast charging power bank with dual USB output and a digital display.", 14_500, 19_000, "Electronics", "🔋", 4.1f, "TechHub NG"),
        Product(10, "Running Sneakers", "Lightweight breathable sneakers with a cushioned sole.", 27_500, 35_000, "Fashion", "👟", 4.4f, "Step Up")
    )

    fun byId(id: Int): Product? = products.firstOrNull { it.id == id }
}
