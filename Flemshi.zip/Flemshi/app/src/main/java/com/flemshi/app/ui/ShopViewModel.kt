package com.flemshi.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.flemshi.app.data.CartItem
import com.flemshi.app.data.Product
import com.flemshi.app.data.SampleData

class ShopViewModel : ViewModel() {

    var query by mutableStateOf("")
        private set

    var selectedCategory by mutableStateOf("All")
        private set

    var cart by mutableStateOf<List<CartItem>>(emptyList())
        private set

    val filteredProducts: List<Product>
        get() = SampleData.products.filter { product ->
            (selectedCategory == "All" || product.category == selectedCategory) &&
                product.name.contains(query.trim(), ignoreCase = true)
        }

    val cartCount: Int get() = cart.sumOf { it.quantity }
    val cartTotal: Int get() = cart.sumOf { it.total }

    fun onQueryChange(value: String) { query = value }

    fun onCategorySelected(category: String) { selectedCategory = category }

    fun addToCart(product: Product) {
        val existing = cart.firstOrNull { it.product.id == product.id }
        cart = if (existing == null) {
            cart + CartItem(product, 1)
        } else {
            cart.map {
                if (it.product.id == product.id) it.copy(quantity = it.quantity + 1) else it
            }
        }
    }

    fun decrease(product: Product) {
        cart = cart.mapNotNull {
            if (it.product.id == product.id) {
                if (it.quantity > 1) it.copy(quantity = it.quantity - 1) else null
            } else it
        }
    }

    fun remove(product: Product) {
        cart = cart.filterNot { it.product.id == product.id }
    }

    fun clearCart() { cart = emptyList() }
}
