package com.flemshi.app.data

data class Product(
    val id: Int,
    val name: String,
    val description: String,
    val price: Int,          // in Naira
    val oldPrice: Int? = null,
    val category: String,
    val emoji: String,       // placeholder until real images are added
    val rating: Float,
    val seller: String
) {
    val discountPercent: Int?
        get() = oldPrice?.let { ((it - price) * 100) / it }
}

data class CartItem(
    val product: Product,
    val quantity: Int
) {
    val total: Int get() = product.price * quantity
}
