package com.flemshi.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val FlemshiOrange = Color(0xFFF68B1E)
val FlemshiDark = Color(0xFF282828)
val FlemshiBackground = Color(0xFFF5F5F5)

private val LightColors = lightColorScheme(
    primary = FlemshiOrange,
    onPrimary = Color.White,
    secondary = FlemshiDark,
    background = FlemshiBackground,
    surface = Color.White,
    onSurface = FlemshiDark
)

@Composable
fun FlemshiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        content = content
    )
}
